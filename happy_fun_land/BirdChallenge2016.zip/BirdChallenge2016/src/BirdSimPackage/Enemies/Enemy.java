package BirdSimPackage.Enemies;

import BirdSimPackage.Background;

/*
 * Enemy.java
 *
 * Authors:	Conor Tracey
 *
 * This class is a subclass of the Entity class. It defines an superclass
 * for all the enemy NPCs to inherit from
 * 
 */

import BirdSimPackage.Entity;
import BirdSimPackage.Main;

public class Enemy extends Entity{
	
	// protected movement variables
	// **domainX and domainY refer to the domain within which the enemy can move
	protected float rightDomainX, leftDomainX;
	protected float speed = 5;
	protected boolean facingRight = true;
	private Background bg = Main.getBg1();
	
	// Constructor for Robot_weak class (calls Entity constructor)
    protected Enemy(float x, float y, int width, int height, float dX, float dY){
        super(x,y,width,height);
        rightDomainX = dY;
        leftDomainX = dX;
        this.velocityX = speed;
    	super.setMovePastEdges(true);
    }
    
    public void update(){
    	// update position based on velocity
    	super.update_position();

    	
    	// keep enemy within movement domain
    	if(facingRight && this.positionX > rightDomainX){
    		facingRight = false;
    		this.velocityX = -speed;
    		//this.positionX = rightDomainX;
    	}
    	else if(!facingRight && this.positionX < leftDomainX){
    		facingRight = true;
    		this.velocityX = speed;
    		//this.positionX = leftDomainX;
    	}
    	
    	super.velocityX = bg.getSpeedX();
    }
    
    public boolean getFacingRight(){
    	return facingRight;
    }
}
